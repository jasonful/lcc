#include <ulp_c.h>

unsigned int a, b;

void entry()
{
    a = 5;
    include(1);
    b = 6;
}
